
select2Request({
    element: 'select[data-name=id_bagian]',
    placeholder: '- Pilih Bagian -',
    url: `${baseUrl}/unit_kerja/bagian/ajax/data_bagian`,
});

