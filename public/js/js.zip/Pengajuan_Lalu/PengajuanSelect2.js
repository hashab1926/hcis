select2Request({
    element: '#penandatangan',
    placeholder: '- Pilih Jenis Pejabat -',
    url: `/karyawan/ajax/data_pejabat`,
});